package com.bon.subanen.dictionary;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdCallback;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;




public class DaywordActivity extends  Activity { 
	
	
	private HashMap<String, Object> mapme = new HashMap<>();
	
    private Timer _timer = new Timer();
    private TimerTask timer_splash;
        
	private LinearLayout linear1;
	private LinearLayout linear12;
	private ScrollView vscroll1;
	private LinearLayout adContainerView;
	private LinearLayout linear2;
	private LinearLayout linear13;
	private ImageView imageview1;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private ImageView save;
	private TextView textview5;
	private LinearLayout linear3;
	private TextView textview4;
	private TextView textview1;
	private TextView textview3;
	private TextView textview2;
	private LinearLayout linear6;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ImageView imageview3;
	private Button button1;
	private ImageView imageview4;
	private Button button2;
	private ImageView imageview2;
	private Button button3;
	

    private static final String AD_UNIT_ID_interstitial = "ca-app-pub-6724883298425146/3030874280";
    private InterstitialAd Interstitial;


    private static final String AD_UNIT_ID_adaptive_banner = "ca-app-pub-6724883298425146/5919394526";
    // private LinearLayout Adc;
    private AdView adView;

    private RewardedAd rewardedAd;
    private static final String AD_UNIT_ID_rewarded = "ca-app-pub-6724883298425146/6657761121";
    boolean isLoading;
        
	private TextToSpeech tts;
	private Intent back_intent = new Intent();
	private SharedPreferences database;
	private Intent main_activity = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.dayword);
            MobileAds.initialize(
                this,
                new OnInitializationCompleteListener() {
                    @Override
                    public void onInitializationComplete(InitializationStatus initializationStatus) {}
                });
                
                
		initialize(_savedInstanceState);
            
                
                
		initializeLogic();
            loadRewardedAd();
            startinterstitial();
	}
	
	private void initialize(Bundle _savedInstanceState) {
            
            
            


            Interstitial = new InterstitialAd(this);
            Interstitial.setAdUnitId(AD_UNIT_ID_interstitial);

            Interstitial.setAdListener(
                new AdListener() {
                    @Override
                    public void onAdLoaded() {
                        // Toast.makeText(MainActivity.this, "onAdLoaded()", Toast.LENGTH_SHORT).show();
                       // ad_progress.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdFailedToLoad(int loadAdError) {
                        final int error = loadAdError;
                        // String error =
                        //  String.format(
                        //  "domain: %s, code: %d, message: %s",
                        //   loadAdError.getDomain(), loadAdError.getCode(), loadAdError.getMessage());
                        //     Toast.makeText(MainActivity.this, "onAdFailedToLoad() with error: " + error, Toast.LENGTH_SHORT) .show();
                      //  Toast.makeText(MainActivity.this, "Error Code is "+error, Toast.LENGTH_SHORT).show();
                      //  ad_progress.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdClosed() {
                        startinterstitial();
                       // ad_progress.setVisibility(View.GONE);
                       
                        Toast.makeText(DaywordActivity. this, "Thank you for supporting this app.", Toast.LENGTH_LONG).show();
                        
                    }
                });
            
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		adContainerView = (LinearLayout) findViewById(R.id.adContainerView);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		save = (ImageView) findViewById(R.id.save);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview1 = (TextView) findViewById(R.id.textview1);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview2 = (TextView) findViewById(R.id.textview2);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		button1 = (Button) findViewById(R.id.button1);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		button2 = (Button) findViewById(R.id.button2);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		button3 = (Button) findViewById(R.id.button3);
		tts = new TextToSpeech(getApplicationContext(), null);
		database = getSharedPreferences("files", Activity.MODE_PRIVATE);
		
            adContainerView.post(new Runnable() {
                    @Override
                    public void run() {
                        loadBanner();
                    }
                });
                
                
                
                
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tts.stop();
				finish();
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapme = new HashMap<>();
				mapme.put("bookmarkwordview", textview1.getText().toString());
				mapme.put("bookmarksynonymview", textview2.getText().toString());
				if ("".contains(database.getString("bookmarkdata", ""))) {
					database.edit().putString("bookmarkdata", new Gson().toJson(mapme)).commit();
				}
				else {
					database.edit().putString("bookmarkdata", database.getString("bookmarkdata", "").concat(",".concat(new Gson().toJson(mapme)))).commit();
				}
				mapme.clear();
				SketchwareUtil.showMessage(getApplicationContext(), "Successfully Saved");
			}
		});
		
		save.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapme = new HashMap<>();
				mapme.put("bookmarkwordview", textview1.getText().toString());
				mapme.put("bookmarksynonymview", textview2.getText().toString());
				if ("".contains(database.getString("bookmarkdata", ""))) {
					database.edit().putString("bookmarkdata", new Gson().toJson(mapme)).commit();
				}
				else {
					database.edit().putString("bookmarkdata", database.getString("bookmarkdata", "").concat(",".concat(new Gson().toJson(mapme)))).commit();
				}
				mapme.clear();
				SketchwareUtil.showMessage(getApplicationContext(), "Successfully Saved");
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				mapme = new HashMap<>();
				mapme.put("bookmarkwordview", textview1.getText().toString());
				mapme.put("bookmarksynonymview", textview2.getText().toString());
				if ("".contains(database.getString("bookmarkdata", ""))) {
					database.edit().putString("bookmarkdata", new Gson().toJson(mapme)).commit();
				}
				else {
					database.edit().putString("bookmarkdata", database.getString("bookmarkdata", "").concat(",".concat(new Gson().toJson(mapme)))).commit();
				}
				mapme.clear();
				SketchwareUtil.showMessage(getApplicationContext(), "Successfully Saved");
			}
		});
		
		linear6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tts.speak(textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString())), TextToSpeech.QUEUE_ADD, null);
			}
		});
		
		linear4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard.");
			}
		});
		
		linear5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(android.content.Intent.ACTION_SEND);intent.setType("text/plain"); intent.putExtra(android.content.Intent.EXTRA_TEXT,textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))); startActivity(Intent.createChooser(intent,"share using"));
				
			}
		});
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tts.speak(textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString())), TextToSpeech.QUEUE_ADD, null);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tts.speak(textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString())), TextToSpeech.QUEUE_ADD, null);
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard.");
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))));
				SketchwareUtil.showMessage(getApplicationContext(), "Copied to clipboard.");
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(android.content.Intent.ACTION_SEND);intent.setType("text/plain"); intent.putExtra(android.content.Intent.EXTRA_TEXT,textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))); startActivity(Intent.createChooser(intent,"share using"));
				
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent intent = new Intent(android.content.Intent.ACTION_SEND);intent.setType("text/plain"); intent.putExtra(android.content.Intent.EXTRA_TEXT,textview1.getText().toString().concat("\nEnglish Synonym:\n".concat(textview2.getText().toString()))); startActivity(Intent.createChooser(intent,"share using"));
				
			}
		});
	}
	
	private void initializeLogic() {
		textview1.setText(database.getString("daywordview", ""));
		textview2.setText(database.getString("daysynonymview", ""));
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_regular.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_regular.ttf"), 0);
		if ("0".equals(database.getString("fontsize", ""))) {
			textview4.setTextSize((int)9);
			textview1.setTextSize((int)8);
			textview3.setTextSize((int)9);
			textview2.setTextSize((int)8);
			button1.setTextSize((int)7);
			button2.setTextSize((int)7);
			button3.setTextSize((int)7);
			textview5.setTextSize((int)7);
		}
		if ("1".equals(database.getString("fontsize", ""))) {
			textview4.setTextSize((int)14);
			textview1.setTextSize((int)13);
			textview3.setTextSize((int)14);
			textview2.setTextSize((int)13);
			button1.setTextSize((int)12);
			button2.setTextSize((int)12);
			button3.setTextSize((int)12);
			textview5.setTextSize((int)12);
		}
		if ("2".equals(database.getString("fontsize", ""))) {
			textview4.setTextSize((int)18);
			textview1.setTextSize((int)16);
			textview3.setTextSize((int)18);
			textview2.setTextSize((int)16);
			button1.setTextSize((int)14);
			button2.setTextSize((int)14);
			button3.setTextSize((int)14);
			textview5.setTextSize((int)14);
		}
		if ("3".equals(database.getString("fontsize", ""))) {
			textview4.setTextSize((int)27);
			textview1.setTextSize((int)24);
			textview3.setTextSize((int)27);
			textview2.setTextSize((int)24);
			button1.setTextSize((int)21);
			button2.setTextSize((int)21);
			button3.setTextSize((int)21);
			textview5.setTextSize((int)21);
		}
		if ("4".equals(database.getString("fontsize", ""))) {
			textview4.setTextSize((int)36);
			textview1.setTextSize((int)32);
			textview3.setTextSize((int)36);
			textview2.setTextSize((int)32);
			button1.setTextSize((int)28);
			button2.setTextSize((int)28);
			button3.setTextSize((int)28);
			textview5.setTextSize((int)28);
                        
                        
                     
		}
                
            mapme = new HashMap<>();
            mapme.put("historywordview", textview1.getText());
            mapme.put("historysynonymview", textview2.getText());
            if ("".contains(database.getString("historydata", ""))) {
                database.edit().putString("historydata", new Gson().toJson(mapme)).commit();
            }
            else {
                database.edit().putString("historydata", database.getString("historydata", "").concat(",".concat(new Gson().toJson(mapme)))).commit();
            }
            mapme.clear();
                
            timer_splash = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                
                                if (rewardedAd.isLoaded())
                                { showRewardedVideo();}
                                else{showInterstitial();}
                            }
                        });
                }
            };
            _timer.schedule(timer_splash, (int)(12000));
            
            
            
            
                
	}
    private void showInterstitial() {
        // Show the ad if it's ready. Otherwise toast and restart the game.
        if (Interstitial != null && Interstitial.isLoaded()) {
            Interstitial.show();
        } else {
            //    Toast.makeText(this, "Ad did not load", Toast.LENGTH_SHORT).show();
            startinterstitial();
        }
    }

    private void startinterstitial() {
        // Request a new ad if one isn't already loaded, hide the button, and kick off the timer.
        if (!Interstitial.isLoading() && !Interstitial.isLoaded()) {
            AdRequest adRequest = new AdRequest.Builder().build();
            Interstitial.loadAd(adRequest);
        }
    }




    @Override
    public void onPause() {
        if (adView != null) {
            adView.pause();
        }
        super.onPause();
    }



    /** Called when returning to the activity */
    @Override
    public void onResume() {
        super.onResume();
        /*
         // It's somewhat arbitrary when your ad request should be made. Here we are simply making
         // a request if there is no valid ad available onResume, but really this can be done at any
         // reasonable time before you plan on showing an ad.
         if (ad == null || ad.isExpired()) {
         // Optionally update location info in the ad options for each request:
         // LocationManager locationManager =
         //     (LocationManager) getSystemService(Context.LOCATION_SERVICE);
         // Location location =
         //     locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
         // adOptions.setUserMetadata(adOptions.getUserMetadata().setUserLocation(location));
         ad_progress.setVisibility(View.VISIBLE);
         AdColony.requestInterstitial(ZONE_ID, listener, adOptions);
         }
         */

        if (adView != null) {
            adView.resume();
        }
    }

    /** Called before the activity is destroyed */
    @Override
    public void onDestroy() {

        if (adView != null) {
            adView.destroy();
        }
        super.onDestroy();
    }

    private void loadBanner() {
        // Create an ad request.
        adView = new AdView(this);
        adView.setAdUnitId(AD_UNIT_ID_adaptive_banner);
        adContainerView.removeAllViews();
        adContainerView.addView(adView);

        AdSize adSize = getAdSize();
        adView.setAdSize(adSize);

        AdRequest adRequest = new AdRequest.Builder().build();

        // Start loading the ad in the background.
        adView.loadAd(adRequest);
    }

    private AdSize getAdSize() {
        // Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float density = outMetrics.density;

        float adWidthPixels = adContainerView.getWidth();

        // If the ad hasn't been laid out, default to the full screen width.
        if (adWidthPixels == 0) {
            adWidthPixels = outMetrics.widthPixels;
        }

        int adWidth = (int) (adWidthPixels / density);

        return AdSize.getCurrentOrientationBannerAdSizeWithWidth(this, adWidth);
    }


    
        
        
        
        
    private void showRewardedVideo() {
        // showVideoButton.setVisibility(View.INVISIBLE);
        if (rewardedAd.isLoaded()) {
            RewardedAdCallback adCallback =
                new RewardedAdCallback() {
                @Override
                public void onRewardedAdOpened() {
                    // Ad opened.
                    //      Toast.makeText(MainActivity.this, "onRewardedAdOpened", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onRewardedAdClosed() {
                    // Ad closed.
                    //     Toast.makeText(MainActivity.this, "onRewardedAdClosed", Toast.LENGTH_SHORT).show();
                    // Preload the next video ad.
                    DaywordActivity.this.loadRewardedAd();
                    Toast.makeText(DaywordActivity. this, "Thank you for supporting this app.", Toast.LENGTH_LONG).show();
                    
                    //ad_progress.setVisibility(View.GONE);
                }

                @Override
                public void onUserEarnedReward(RewardItem rewardItem) {

                    // User earned reward.
                    //     Toast.makeText(MainActivity.this, "onUserEarnedReward", Toast.LENGTH_SHORT).show();
                    //   addCoins(rewardItem.getAmount());
                    Toast.makeText(DaywordActivity.this, "Thank you for Supporting this app, your reward is " + rewardItem.getAmount() ,Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onRewardedAdFailedToShow(AdError adError) {
//                  // Ad failed to display
                 //   .setVisibility(View.GONE);

                  //  Toast.makeText(DaywordActivity.this, "Sorry There is no Video Ads this Time.", Toast.LENGTH_SHORT) .show();
                }
            };
            rewardedAd.show(this, adCallback);
        }
    }
    private void loadRewardedAd() {
        if (rewardedAd == null || !rewardedAd.isLoaded()) {
            rewardedAd = new RewardedAd(this, AD_UNIT_ID_rewarded);
            isLoading = true;
            rewardedAd.loadAd(
                new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override
                    public void onRewardedAdLoaded() {
                        // Ad successfully loaded.
                        DaywordActivity.this.isLoading = false;
                        //    Toast.makeText(MainActivity.this, "onRewardedAdLoaded", Toast.LENGTH_SHORT).show();
                     //   ad_progress.setVisibility(View.GONE);
                    }

                    @Override
                    public void onRewardedAdFailedToLoad(LoadAdError loadAdError) {
//                        // Ad failed to load.

                        DaywordActivity.this.isLoading = false;
//                                              //    Toast.makeText(MainActivity.this, "onRewardedAdFailedToLoad", Toast.LENGTH_SHORT)  .show();
                      //  ad_progress.setVisibility(View.GONE);
                    }
                });
        }
    }


    
        
        
        
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		
            
            tts.stop();
            
            if (rewardedAd.isLoaded()){
                showRewardedVideo();
            }
            else{
                showInterstitial();
            }
            
		finish();
	}
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
